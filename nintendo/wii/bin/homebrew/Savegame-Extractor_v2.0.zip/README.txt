+--------------------------------------+
| Savegame Extractor v2.0 by Waninkoko |
+--------------------------------------+
|        www.teknoconsolas.info        |
+--------------------------------------+


+--------------+
| DESCRIPTION: |
+--------------+

This application allows you to copy a savegame from
your Wii to a SD card (even those savegames that
you can not copy through the system menu).


+-------------+
| HOW TO USE: |
+-------------+

1. Run this application.
2. Insert the game DVD and press RESET or A button
   (Wiimote not supported).


+--------+
| KUDOS: |
+--------+

- bushing and marcan
- danny.ml
- ElOtroLado.net (I like the new look :P)
