Developed by Uffe Flarup - www.flarup.org

Music by Nicklas Schmidt - www.nicklas-schmidt.com

For more information about WiiWare version (Paint Splash) - www.knapnokgames.com

Powered by HBC, devkitPro, GRRLIB and associated libraries.

Thanks to:
- Users of the GRRLib forum for their help during development of this program.
- CodeMii for tutorials.
- Arikado for MP3 playback tutorial.
- Kidspaint users for feedback and suggestions.
