*** Playstats v.1.11 ***

Utility for analysing the play history on your Wii.

This can be distributed in any non-chargeable format as long as this notice is retained and no charge is made for this program or anything derived from its source.  No warranty, etc, etc.

Programming and graphics by chris
Modeling by helen
Uses DolLZ, GRRLIB, libogc, etc.

Bugs, feedback to chris@toxicbreakfast.com

*** RELEASE NOTES ***

v1.11 28/01/2019

	Recompiled with latest devkitpro for compatibility with newer Wiimotes.

v1.1  08/10/2011

	Partially fixed the "wacky stats" bug.  Added sanity checks to work around any remaining problems.
	Added Unicode support.
	Added ability to log stats to SD card.

v1.02 19/05/2009

	Fixed bug that could cause the program to hang on loading or skip some play history messages (thanks bengalih).

v1.01 14/05/2009

	Fixed bug that was causing strange results for some people (thanks Electrokidd) but unsolved bugs of this nature remain.
	Source has support for reading from an SD dump of the messageboard file.

v1.0 02/04/2009

	Initial release.

www.toxicbreakfast.com
TOX 010
